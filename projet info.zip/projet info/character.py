class Character:
    def __init__(self, character_id, active_effect, end_effect):
        self.character_id = character_id
        self.active_effect = active_effect
        self.end_effect = end_effect
        self.counter = 16
