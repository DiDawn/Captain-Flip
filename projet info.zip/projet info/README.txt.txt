Pour lancer le jeu, utilisez le fichier main.py.
Mis à part pygame, aucun module non intégré n'est nécessaire.